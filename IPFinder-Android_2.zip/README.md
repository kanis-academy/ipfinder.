# IP Finder (Android)

1. Créez un dépôt GitHub et envoyez tous ces fichiers (dossier `.github` compris).
2. Onglet Actions > « Build APK » > Run workflow.
3. Téléchargez l’artefact `IPFinder-APK`, dézippez, installez `app-debug.apk`.
4. Dans l’app : activez le service d’accessibilité « IP Finder », désactivez le Wi-Fi (données mobiles), choisissez votre VPN, lancez.

## Nouveautés
- Motifs : IP complète = exacte, `^` commence par, `$` finit par, `=` exact, sans symbole = contient.
- Choix de l'IP comparée : publique (ipify) ou cellulaire locale (10.x.x.x).
- Correction : une lecture d'IP en retard ne peut plus fausser l'essai suivant.
