package com.ipfinder.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Vibrator
import android.provider.Settings
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {

    private lateinit var web: WebView
    private val ui = Handler(Looper.getMainLooper())

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    @Volatile private var ipJob = 0

    private fun js(code: String) { ui.post { web.evaluateJavascript(code, null) } }

    private fun localCellularIp(): String {
        try {
            val all = java.net.NetworkInterface.getNetworkInterfaces() ?: return ""
            for (nif in all) {
                if (!nif.isUp || nif.isLoopback) continue
                val n = nif.name.lowercase()
                if (n.startsWith("wlan") || n.startsWith("tun") || n.startsWith("ppp") ||
                    n.startsWith("tap") || n.startsWith("p2p") || n.startsWith("dummy")) continue
                for (a in nif.inetAddresses) {
                    if (a is java.net.Inet4Address && !a.isLoopbackAddress) return a.hostAddress ?: ""
                }
            }
        } catch (e: Exception) {}
        return ""
    }

    inner class Bridge {
        @JavascriptInterface
        fun serviceOn(): Boolean = AirplaneService.instance != null

        @JavascriptInterface
        fun openAccessibility() {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }

        @JavascriptInterface
        fun cycleAirplane() {
            ui.post {
                val s = AirplaneService.instance
                if (s == null) js("onCycle(false)") else s.cycle { ok -> js("onCycle($ok)") }
            }
        }

        // IP cellulaire locale (celle que montre l'app BKCBEBE, ex. 10.209.x.x)
        @JavascriptInterface
        fun fetchLocalIp() {
            val id = ++ipJob
            Thread {
                var ip = ""
                for (i in 0 until 15) {
                    if (id != ipJob) return@Thread
                    ip = localCellularIp()
                    if (ip.isNotEmpty()) break
                    Thread.sleep(2000)
                }
                if (id == ipJob) js("onIp('$ip')")
            }.start()
        }

        // IP publique (vue par Internet)
        @JavascriptInterface
        fun fetchIp() {
            val id = ++ipJob
            Thread {
                var ip = ""
                for (i in 0 until 6) {
                    if (id != ipJob) return@Thread
                    try {
                        val c = URL("https://api.ipify.org").openConnection() as HttpURLConnection
                        c.connectTimeout = 4000
                        c.readTimeout = 4000
                        ip = c.inputStream.bufferedReader().readText().trim()
                        c.disconnect()
                        if (ip.isNotEmpty()) break
                    } catch (e: Exception) {
                        Thread.sleep(2000)
                    }
                }
                if (!Regex("^[0-9.]+$").matches(ip)) ip = ""
                if (id == ipJob) js("onIp('$ip')")
            }.start()
        }

        @JavascriptInterface
        fun listApps(): String {
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val pm = packageManager
            val arr = JSONArray()
            pm.queryIntentActivities(q, 0)
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
                .forEach {
                    arr.put(JSONObject().put("n", it.loadLabel(pm).toString()).put("p", it.activityInfo.packageName))
                }
            return arr.toString()
        }

        @JavascriptInterface
        fun openVpn(target: String): Boolean {
            return try {
                val i = if (target.contains("://")) Intent(Intent.ACTION_VIEW, Uri.parse(target))
                else packageManager.getLaunchIntentForPackage(target)
                if (i == null) false else { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); true }
            } catch (e: Exception) { false }
        }

        @Suppress("DEPRECATION")
        @JavascriptInterface
        fun notifyFound() {
            try {
                (getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(longArrayOf(0, 200, 100, 200), -1)
                ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100).startTone(ToneGenerator.TONE_PROP_BEEP, 300)
            } catch (e: Exception) {}
        }
    }
}
