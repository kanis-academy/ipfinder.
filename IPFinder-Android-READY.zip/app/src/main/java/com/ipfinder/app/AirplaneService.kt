package com.ipfinder.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Automatise le cycle uniquement après activation volontaire du service par l'utilisateur.
 * L'état réel est lu dans Settings.Global : on ne suppose jamais qu'un clic a réussi.
 */
class AirplaneService : AccessibilityService() {
    companion object { @Volatile var instance: AirplaneService? = null }

    private val handler = Handler(Looper.getMainLooper())
    private val labels = listOf("mode avion", "airplane mode", "airplane", "flight mode", "modo avion", "flugmodus")

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { if (instance === this) instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { if (instance === this) instance = null; handler.removeCallbacksAndMessages(null); super.onDestroy() }
    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun isOn(): Boolean = try {
        Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
    } catch (_: Exception) { false }

    fun cycle(done: (Boolean) -> Unit) {
        // S'assurer d'abord que le mode avion est désactivé, même s'il était déjà actif.
        setAirplane(false, 0) { off ->
            if (!off) {
                closePanel()
                done(false)
            } else {
                handler.postDelayed({
                    setAirplane(true, 0) { on ->
                        if (!on) {
                            closePanel()
                            done(false)
                        } else {
                            handler.postDelayed({
                                setAirplane(false, 0) { finalOff ->
                                    handler.postDelayed({ closePanel(); done(finalOff && !isOn()) }, 6000)
                                }
                            }, 3500)
                        }
                    }
                }, 5000)
            }
        }
    }

    private fun setAirplane(enabled: Boolean, attempt: Int, done: (Boolean) -> Unit) {
        if (isOn() == enabled) { done(true); return }
        if (attempt >= 6) { done(false); return }
        val tileAlreadyVisible = findTile(rootInActiveWindow) != null
        if (!tileAlreadyVisible && attempt == 0) performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        handler.postDelayed({
            val clickable = findTile(rootInActiveWindow)?.let { tile ->
                var current: AccessibilityNodeInfo? = tile
                while (current != null && !current.isClickable) current = current.parent
                current
            }
            val clicked = clickable?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
            if (!clicked) {
                handler.postDelayed({ setAirplane(enabled, attempt + 1, done) }, 800)
            } else {
                waitForState(enabled, 0, done)
            }
        }, if (tileAlreadyVisible) 300 else 900)
    }

    private fun waitForState(expected: Boolean, checks: Int, done: (Boolean) -> Unit) {
        if (isOn() == expected) { done(true); return }
        if (checks >= 12) { done(false); return }
        handler.postDelayed({ waitForState(expected, checks + 1, done) }, 500)
    }

    private fun closePanel() { if (findTile(rootInActiveWindow) != null) performGlobalAction(GLOBAL_ACTION_BACK) }

    private fun findTile(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        val description = ((node.text?.toString() ?: "") + " " + (node.contentDescription?.toString() ?: "")).lowercase()
        if (labels.any { description.contains(it) }) return node
        for (index in 0 until node.childCount) {
            val found = findTile(node.getChild(index))
            if (found != null) return found
        }
        return null
    }
}
