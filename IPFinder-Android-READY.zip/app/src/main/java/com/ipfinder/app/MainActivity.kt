package com.ipfinder.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Vibrator
import android.provider.Settings
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var ipJob = 0

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = false
        web.settings.allowFileAccessFromFileURLs = false
        web.settings.allowUniversalAccessFromFileURLs = false
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return true
                return !(uri.scheme == "file" && uri.path?.startsWith("/android_asset/") == true)
            }
        }
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    override fun onDestroy() {
        ipJob++
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }

    private fun js(code: String) { ui.post { if (::web.isInitialized) web.evaluateJavascript(code, null) } }

    private fun isValidIpv4(value: String): Boolean {
        val parts = value.split('.')
        return parts.size == 4 && parts.all {
            it.isNotEmpty() && it.length <= 3 && it.all(Char::isDigit) && (it.toIntOrNull()?.let { value -> value in 0..255 } == true)
        }
    }

    // Adresse IPv4 attribuée au réseau mobile, et non à l'interface Wi-Fi ou au VPN.
    private fun localCellularIp(): String = try {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        for (network in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(network) ?: continue
            if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
            val props = cm.getLinkProperties(network) ?: continue
            for (link in props.linkAddresses) {
                val address = link.address
                val value = address.hostAddress ?: continue
                if (address is java.net.Inet4Address && !address.isLoopbackAddress &&
                    !address.isLinkLocalAddress && isValidIpv4(value)) return value
            }
        }
        ""
    } catch (_: SecurityException) { "" } catch (_: Exception) { "" }

    private fun airplaneModeOn(): Boolean = try {
        Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
    } catch (_: Exception) { false }

    private fun vpnActive(): Boolean {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.allNetworks.any { network ->
            cm.getNetworkCapabilities(network)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
        }
    }

    inner class Bridge {
        @JavascriptInterface fun serviceOn(): Boolean = AirplaneService.instance != null
        @JavascriptInterface fun airplaneOn(): Boolean = airplaneModeOn()
        @JavascriptInterface fun vpnActive(): Boolean = this@MainActivity.vpnActive()

        @JavascriptInterface
        fun openAccessibility() {
            ui.post { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        @JavascriptInterface
        fun cycleAirplane() {
            ui.post {
                val service = AirplaneService.instance
                if (service == null) js("onCycle(false)")
                else service.cycle { ok -> js("onCycle($ok)") }
            }
        }

        @JavascriptInterface
        fun fetchLocalIp() {
            val id = ++ipJob
            Thread {
                var ip = ""
                for (attempt in 0 until 18) {
                    if (id != ipJob) return@Thread
                    ip = localCellularIp()
                    if (ip.isNotEmpty()) break
                    try { Thread.sleep(1500) } catch (_: InterruptedException) { return@Thread }
                }
                if (id == ipJob) js("onIp(${JSONObject.quote(ip)})")
            }.start()
        }

        @JavascriptInterface
        fun fetchIp() {
            val id = ++ipJob
            Thread {
                var ip = ""
                for (attempt in 0 until 6) {
                    if (id != ipJob) return@Thread
                    var connection: HttpURLConnection? = null
                    try {
                        connection = URL("https://api4.ipify.org").openConnection() as HttpURLConnection
                        connection.connectTimeout = 5000
                        connection.readTimeout = 5000
                        connection.requestMethod = "GET"
                        val candidate = connection.inputStream.bufferedReader().use { it.readText().trim() }
                        if (isValidIpv4(candidate)) { ip = candidate; break }
                    } catch (_: Exception) {
                        try { Thread.sleep(1500) } catch (_: InterruptedException) { return@Thread }
                    } finally { connection?.disconnect() }
                }
                if (id == ipJob) js("onIp(${JSONObject.quote(ip)})")
            }.start()
        }

        @JavascriptInterface
        fun listApps(): String {
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val pm = packageManager
            val result = JSONArray()
            pm.queryIntentActivities(query, 0)
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
                .forEach { result.put(JSONObject().put("n", it.loadLabel(pm).toString()).put("p", it.activityInfo.packageName)) }
            return result.toString()
        }

        @JavascriptInterface
        fun openVpn(target: String): Boolean {
            val value = target.trim()
            val intent = try {
                if (value.startsWith("https://", true) || value.startsWith("http://", true)) {
                    Intent(Intent.ACTION_VIEW, Uri.parse(value))
                } else {
                    if (!value.matches(Regex("^[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+$"))) return false
                    packageManager.getLaunchIntentForPackage(value) ?: return false
                }
            } catch (_: Exception) { return false }
            ui.post {
                try {
                    startActivity(intent)
                    js("onVpnOpened(true)")
                } catch (_: Exception) { js("onVpnOpened(false)") }
            }
            return true
        }

        @Suppress("DEPRECATION")
        @JavascriptInterface
        fun notifyFound() {
            try { (getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(250) } catch (_: Exception) {}
        }
    }
}
