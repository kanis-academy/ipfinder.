# IP Finder — Android

Application Android qui compare l'adresse IPv4 publique ou l'adresse IPv4 du réseau mobile avec une liste de motifs saisie par l'utilisateur.

## Fonctionnement

- **IP publique** : adresse IPv4 vue depuis Internet, récupérée via `https://api4.ipify.org`.
- **IP cellulaire locale** : adresse IPv4 attribuée à un réseau mobile Android (interface Wi-Fi et interface VPN exclues).
- **Correspondance** : adresse exacte, préfixe `^`, suffixe `$`, égalité stricte `=` ou texte contenu.
- **VPN** : ouvre une application VPN choisie par l'utilisateur. IP Finder ne crée pas le tunnel VPN et ne peut pas garantir que l'application VPN se connecte.
- **Mode avion** : l'assistant d'accessibilité ouvre les réglages rapides, demande le cycle et vérifie l'état Android avant de continuer.

## Compiler l'APK avec GitHub depuis un téléphone

1. Crée un dépôt GitHub et envoie **tout le contenu** de cette archive, y compris le dossier caché `.github/workflows`.
2. Ouvre le dépôt, puis l'onglet **Actions**.
3. Sélectionne **Build APK**, puis **Run workflow**.
4. Attends la fin du workflow. Il doit être vert.
5. Ouvre l'exécution terminée et télécharge l'artefact **IPFinder-APK**.
6. Décompresse l'artefact et installe `app-debug.apk` sur Android. Autorise l'installation depuis cette source si Android le demande.

Le workflow installe Java 17, Android SDK Platform 34 / Build Tools 34.0.0 et Gradle 8.7. Le projet ne contient pas de wrapper Gradle : le workflow installe Gradle lui-même.

## Première configuration

1. Ouvre IP Finder et appuie sur **Commencer**.
2. Active l'assistant IP Finder dans les paramètres d'accessibilité Android, puis reviens dans l'application.
3. Pour rechercher l'IP mobile, désactive le Wi-Fi et déconnecte tout VPN.
4. Colle tes IP ou motifs, puis choisis **Publique** ou **Cellulaire locale**.
5. Lance la recherche. Après chaque tentative infructueuse, l'assistant tente le cycle du mode avion et vérifie son état.
6. Quand une IP correspond, choisis ton application VPN et appuie sur **Ouvrir mon VPN**.

## Limites importantes

- Android peut empêcher ou modifier l'automatisation du mode avion selon la marque, la version et l'interface des réglages rapides. Le résultat est vérifié ; en cas d'échec, la recherche s'arrête au lieu de prétendre que le cycle a réussi.
- L'utilisateur doit activer explicitement le service d'accessibilité. Ce service sert uniquement à repérer et toucher la tuile Mode avion dans les réglages rapides.
- Une adresse IP publique peut être différente de l'adresse cellulaire privée. Les réseaux mobiles peuvent utiliser du CGNAT ; l'IP locale n'est pas nécessairement routable depuis Internet.
- La détection de connexion VPN indique seulement si Android expose un transport VPN actif. Elle ne vérifie pas la qualité, la localisation ou la sécurité du fournisseur VPN.
- La recherche n'est pas une surveillance permanente en arrière-plan : elle s'exécute lorsque l'utilisateur lance la recherche dans l'application.
- L'application nécessite un accès Internet pour interroger le service IP publique.
