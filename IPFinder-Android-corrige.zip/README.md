# IP Finder Android

## Compilation APK sur GitHub

1. Créez un dépôt GitHub avec une branche `main`.
2. Extrayez cette archive et téléversez **tout son contenu** à la racine du dépôt (y compris `.github`).
3. Ouvrez l'onglet **Actions**.
4. Sélectionnez **Build IP Finder APK**, puis **Run workflow**.
5. À la fin, ouvrez l'exécution réussie et téléchargez l'artefact **IPFinder-APK**.
6. Décompressez l'artefact et installez `app-debug.apk`.

## Première utilisation

- Ouvrez IP Finder.
- Activez le service d'accessibilité IP Finder seulement si vous souhaitez utiliser l'automatisation du mode avion.
- Suivez les instructions affichées dans l'application et choisissez votre VPN.
- La recherche compare l'adresse IPv4 publique retournée par `api4.ipify.org` à votre liste.

## Notes importantes

- La bascule du mode avion dépend de la version Android, du fabricant et de l'interface des réglages rapides. Android peut demander une action ou confirmation manuelle; le service d'accessibilité ne peut pas garantir le fonctionnement sur tous les téléphones.
- L'application ne fournit pas elle-même un VPN et ne change pas l'adresse IP à elle seule : elle teste l'IP publique et peut ouvrir l'application VPN choisie.
- L'activation du service d'accessibilité donne à l'application la capacité de lire et d'interagir avec certains éléments visibles à l'écran. Activez-le uniquement si vous faites confiance à l'application.
