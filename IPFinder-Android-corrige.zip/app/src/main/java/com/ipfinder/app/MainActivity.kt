package com.ipfinder.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Vibrator
import android.provider.Settings
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {

    private lateinit var web: WebView
    private val ui = Handler(Looper.getMainLooper())

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = false
        web.settings.allowFileAccessFromFileURLs = false
        web.settings.allowUniversalAccessFromFileURLs = false
        web.settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }


    @Deprecated("Deprecated in Android API 33; retained for compatibility")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) {
            web.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        if (::web.isInitialized) {
            web.removeJavascriptInterface("Android")
            web.stopLoading()
            web.loadUrl("about:blank")
            web.destroy()
        }
        super.onDestroy()
    }

    private fun js(code: String) { ui.post { web.evaluateJavascript(code, null) } }

    inner class Bridge {
        @JavascriptInterface
        fun serviceOn(): Boolean = AirplaneService.instance != null

        @JavascriptInterface
        fun openAccessibility() {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }

        @JavascriptInterface
        fun cycleAirplane() {
            ui.post {
                val s = AirplaneService.instance
                if (s == null) js("onCycle(false)") else s.cycle { ok -> js("onCycle($ok)") }
            }
        }

        @JavascriptInterface
        fun fetchIp() {
            Thread {
                var ip = ""
                for (i in 0 until 10) {
                    try {
                        val c = URL("https://api4.ipify.org").openConnection() as HttpURLConnection
                        c.connectTimeout = 4000
                        c.readTimeout = 4000
                        ip = c.inputStream.bufferedReader().readText().trim()
                        c.disconnect()
                        if (ip.isNotEmpty()) break
                    } catch (e: Exception) {
                        Thread.sleep(2000)
                    }
                }
                if (!Regex("^[0-9.]+$").matches(ip)) ip = ""
                js("onIp('$ip')")
            }.start()
        }

        @JavascriptInterface
        fun listApps(): String {
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val pm = packageManager
            val arr = JSONArray()
            pm.queryIntentActivities(q, 0)
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
                .forEach {
                    arr.put(JSONObject().put("n", it.loadLabel(pm).toString()).put("p", it.activityInfo.packageName))
                }
            return arr.toString()
        }

        @JavascriptInterface
        fun openVpn(target: String): Boolean {
            return try {
                val i = if (target.contains("://")) Intent(Intent.ACTION_VIEW, Uri.parse(target))
                else packageManager.getLaunchIntentForPackage(target)
                if (i == null) false else { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); true }
            } catch (e: Exception) { false }
        }

        @Suppress("DEPRECATION")
        @JavascriptInterface
        fun notifyFound() {
            try {
                (getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(longArrayOf(0, 200, 100, 200), -1)
                ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100).startTone(ToneGenerator.TONE_PROP_BEEP, 300)
            } catch (e: Exception) {}
        }
    }
}
