package com.ipfinder.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AirplaneService : AccessibilityService() {

    companion object {
        var instance: AirplaneService? = null
    }

    private val h = Handler(Looper.getMainLooper())
    private val keys = listOf("avion", "airplane", "aeroplane", "flight mode", "vuelo", "flugmodus", "modo avi")

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // Ouvre les réglages rapides, appuie sur la tuile « Mode avion » (activer), attend, rappuie (désactiver).
    fun cycle(done: (Boolean) -> Unit) {
        performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        h.postDelayed({
            clickWithRetry(5) { on ->
                if (!on) {
                    performGlobalAction(GLOBAL_ACTION_BACK)
                    done(false)
                } else {
                    h.postDelayed({
                        clickWithRetry(5) { off ->
                            h.postDelayed({
                                performGlobalAction(GLOBAL_ACTION_BACK)
                                done(off)
                            }, 600)
                        }
                    }, 3500)
                }
            }
        }, 1500)
    }

    private fun clickWithRetry(n: Int, cb: (Boolean) -> Unit) {
        if (clickTile()) cb(true)
        else if (n <= 1) cb(false)
        else h.postDelayed({ clickWithRetry(n - 1, cb) }, 700)
    }

    private fun clickTile(): Boolean {
        val root = rootInActiveWindow ?: return false
        var n: AccessibilityNodeInfo? = find(root) ?: return false
        while (n != null) {
            if (n.isClickable) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
        }
        return false
    }

    private fun find(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        val t = ((n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")).lowercase()
        if (keys.any { t.contains(it) }) return n
        for (i in 0 until n.childCount) {
            val r = find(n.getChild(i))
            if (r != null) return r
        }
        return null
    }
}
